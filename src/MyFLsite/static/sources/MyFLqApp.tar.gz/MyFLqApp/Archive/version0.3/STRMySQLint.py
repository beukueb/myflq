# coding: utf-8
#Log in function
def login():
    """
    Puts in the global namespace the formed connection with the db using variablenames: conn, sql
    Make sure you don't have already conn and sql in your global namespace
    """
    import MySQLdb
    conn = MySQLdb.connect(host = "localhost",
                           user = "profiler",
                           passwd = "many#1profile",
                           db = "strdb")
    sql = conn.cursor(MySQLdb.cursors.DictCursor)
    return (conn,sql)
def logout(conn,sql):
    sql.close()
    conn.commit()
    conn.close()
#Function for adding samples to the database
def makeEntry(sequences,seqCounts,locusName,labID,passphrase,technology='Illumina',filterLevel=None,forwardP=None,reverseP=None,
            validatedInfo=None,manualRevision=False,population='NA',stepwise=False):
    """
    Is the starting function for new samples (all the relevant sequences for one locus of one profile) to be added to the database.
    Can be used directly, or by a function that calls it by means of an url api interface.
    In any case, the logic of these functions has to be followed.
    The MySQL database itself does not make all the necessary checks and balances, that these functions do.

    Sequences, seqCounts (and validatedInfo if provided) should be lists of equal length
    The different lists should be structured as follows:
        sequences     = [s1, s2, s3]
        seqCounts     = [c1, c2, c3]
        validatedInfo = [x1, x2, x3] (if provided)
    
    Validation info has to be provided for each sequence (s) at the same index in a list,
    the validation values can be:
        x == 'NA' => s is not validated
        x == 'a[:X[:R#repeat]]'
                => s is validated as an allele with allelenumber/name X, and if STR locus repeatsize of locus #repeat (in bp), e.g.:
                        x == 'a' => only validated as allele, no extra info
                        x == 'a:10.1'    => validated as allele 10.1
                        x == 'a:10.1:R4   => validated as allele 10.1 from a locus with a repeatsize of 4 bp
        x > 0   => s is a validated error of the allele (s) with index x
                    e.g. if s3 is a validated error of s2, x should equal 2
    If you are not sure on how to provide validation info, don't provide it!
    """
    #Check conditions
    if not ((forwardP and reverseP) or (not forwardP and not reverseP)):
        raise Exception("either give both primers or neither")
    if type(sequences) != list: sequences=[sequences]
    if type(seqCounts) != list: seqCounts=[seqCounts]
    if validatedInfo and type(validatedInfo) != list: validatedInfo=[validatedInfo]
    if len(sequences) != len(seqCounts) or (validatedInfo and len(validatedInfo) != len(sequences)):
        raise Exception("Number of sequences, sequences-counts and/or validation-info does not match")
    
    #Login to database
    conn,sql = login() #Necessary to have a unique connection as makeEntry makes use of MySQL LAST_INSERT_ID() which is connection dependent
    
    #Check authentification of submitting institution
    sql.execute ("SELECT passphrase FROM laboratories WHERE labID = %s", (labID))
    if sql.rowcount == 0: raise Exception("Lab identifier not known, register first")
    elif sql.fetchone()['passphrase'] != passphrase: raise Exception("Passphrase for "+labID+" not correct!")
        
    #First table that needs to be updated is BASEseqs: take all seqID's for the sequences and primers
    seqIDs=[]
    if forwardP and reverseP: sequences+=[forwardP,reverseP]
    for seq in sequences:
        sql.execute ("SELECT seqID FROM BASEseqs WHERE sequence = %s", (seq))
        if sql.rowcount == 0: 
            sql.execute ("INSERT INTO BASEseqs (sequence) VALUES (%s)", (seq))
            sql.execute ("SELECT seqID FROM BASEseqs WHERE sequence = %s", (seq))
        seqIDs.append(sql.fetchone()['seqID'])
    if forwardP and reverseP:
        reverseP, forwardP = seqIDs.pop(), seqIDs.pop()
        sequences.pop(),sequences.pop()
    
    #Second table to be updated: BASEtech
    #forwardP and reverseP could be python None and so MySQL NULL => use null-safe equality operator '<=>' to test for equality considering also NULL values
    sql.execute ("SELECT techID, count FROM BASEtech WHERE forwardP <=> %s AND reverseP <=> %s AND locusName = %s AND technology = %s AND filterLevel <=> %s"
                    ,(forwardP,reverseP,locusName,technology,filterLevel))
        
    if sql.rowcount == 0:
        sql.execute ("INSERT INTO BASEtech (forwardP, reverseP, locusName, technology, filterLevel) VALUES (%s,%s,%s,%s,%s)"
                     ,(forwardP, reverseP, locusName, technology, filterLevel))
        sql.execute("SELECT LAST_INSERT_ID()")
        techID=sql.fetchone()['LAST_INSERT_ID()']
    elif sql.rowcount == 1:
        sqlResult=sql.fetchone()
        techID=sqlResult['techID']
        sql.execute("UPDATE BASEtech SET count = %s WHERE techID = %s"
                    ,(sqlResult['count']+1,techID))
    else: raise Exception("BASEtech is degraded, same tech entry present more than one time")
    
    #Third table that needs to be updated is BASElocustrack
    sql.execute ("INSERT INTO BASElocustrack (techID, labID, validated, manualRevision, nrSeqs, nrReads, population) VALUES (%s,%s,%s,%s,%s,%s,%s)"
                     ,(techID, labID, bool(validatedInfo), manualRevision, len(sequences), sum(seqCounts), population))
    #Fetch entryID from previous step
    #!!!Don't do any other sql inserts between updating BASEbasetrack and before fetching this entryID!!!
    sql.execute("SELECT LAST_INSERT_ID();")
    entryID=sql.fetchone()['LAST_INSERT_ID()']
    
    #Last table to update: BASEstat
    if validatedInfo:
        alleleValidation=[v[2:] if 'a:' in str(v) and v != 'a:' else None for v in validatedInfo]
        validatedInfo=[0 if 'a:' in str(v) else v for v in validatedInfo]
        validatedInfo=[-1 if v=='NA' else v for v in validatedInfo]
    else:
        alleleValidation=[None for s in sequences]
        validatedInfo=[-1 for s in sequences]
    for seqID,seqCount,valid,avalid in zip(seqIDs,seqCounts,validatedInfo,alleleValidation):
        if valid and valid > 0: valid = seqIDs[valid-1] # -1 as I request list number and not python index
        sql.execute ("INSERT INTO BASEstat (entryID, seqID, validated, alleleValidation, seqCount) VALUES (%s,%s,%s,%s,%s)" 
                    ,(entryID, seqID, valid, avalid, seqCount))
        
    #Log out of database
    logout(conn,sql)
    return entryID
        
#Functions for adding users/laboratories
def addLab(labID,passphrase):
    conn,sql=login()
    sql.execute ("SELECT passphrase FROM laboratories WHERE labID = %s",(labID))
    if sql.rowcount != 0: raise Exception("Lab identifier not unique, you either already registered or need to choose another identifier")
    else:
        sql.execute ("INSERT INTO laboratories (labID, passphrase) VALUES (%s,%s)", (labID,passphrase))
    logout(conn,sql)

def makeRandomPassphrase(minLength=8,maxLength=20):
    if maxLength > 40: raise Exception("The underlying database stores passphrases only up to 40 characters")
    import random
    length=random.randint(minLength,maxLength)
    passphrase=''
    for l in range(length): passphrase+=random.sample(makeRandomPassphrase.symbols,1)[0]
    return passphrase
makeRandomPassphrase.exsymbols={'"',"'",'\\','/','{','}','(',')','&','`'}
makeRandomPassphrase.symbols={chr(a+33) for a in range(94) if chr(a+33) not in makeRandomPassphrase.exsymbols}