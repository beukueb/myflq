from django.db import models

# Create your models here.

#Setup
from django.contrib.auth.models import User
class UserResources(models.Model):
    """
    This model indicates which databases the user has at their disposal.
    """
    user = models.ForeignKey(User)
    dbname = models.CharField(max_length=200)
    isAlreadyCommitted = models.BooleanField(default=False)
    creationDate = models.DateField(auto_now_add=True)
    
    def __str__(self):
        return self.dbname
        
    def dbusername(self):
        """
        This is the username for the database, linked to the MyFLsite current user 
        """
        return 'myfls_'+self.user.username
    
    def fulldbname(self):
        """
        This is the name how it will be used in the database system.
        It includes a general MyFLsite prefix, and the username so that
        different users can use the same short dbname
        """
        return 'myfls_'+self.user.username+'_'+self.dbname
        
class Primer(models.Model):
    """
    This model lists all primers analyzed per database
    """
    dbname = models.ForeignKey(UserResources)
    locusName = models.CharField(max_length=200)
    locusType = models.IntegerField(null=True,blank=True,max_length=1)
    forwardPrimer = models.CharField(max_length=200)
    reversePrimer = models.CharField(max_length=200)
    
    class Meta:
        unique_together = ("dbname", "locusName")
    
    def __str__(self):
        return self.locusName
        
class AlleleFiles(models.Model):
    """
    One instance extends UserResources pointing to an allele file that can
    be used to populate the MyFLq relevant database
    """
    dbname = models.OneToOneField(UserResources)
    alleleFile = models.FileField(upload_to=lambda instance,filename: 'allelefiles/'+instance.dbname.fulldbname()+'.csv')
    
    def __str__(self):
        return self.alleleFile.url
        

#Analysis
from django.core.exceptions import ValidationError
def validate_percentage(value):
    if value and not (0 < value <= 1):
        raise ValidationError('{} is not within [0-1]'.format(value))

def generateFileName(instance,filename):
    instance.originalFilename = filename
    return 'fastqfiles/'+instance.dbname.fulldbname()+'.fastq'

class Analysis(models.Model):
    """
    Gathers all information for starting an analysis.
    """
    dbname = models.ForeignKey(UserResources)
    fastq = models.FileField(upload_to=generateFileName)
    originalFilename = models.CharField(max_length=128,null=True)
    negativeReadsFilter = models.BooleanField(default=True)
    #kMerAssign = 
    primerBuffer = models.IntegerField(default=0)
    flankOut = models.BooleanField(default=True)
    stutterBuffer = models.IntegerField(default=1)
    useCompress = models.BooleanField(default=True)
    withAlignment = models.BooleanField(default=False)
    threshold = models.FloatField(default=0.005)
    clusterInfo = models.BooleanField(default=True)
    randomSubset = models.FloatField(blank=True,null=True,help_text='Should be between 0 and 1, or blank',
                                     validators=[validate_percentage])
    progress = models.CharField(max_length=2,default='Q',choices=[('Q','Queued'),('P','Processing'),('F','Finished'),('FA','Failed')])
    creationTime = models.TimeField(auto_now_add=True)

    def __str__(self):
        return 'Analysis: db = '+str(self.dbname)+', file = '+self.originalFilename+' [settings => '+ \
            'negativeReadsFilter = '+str(self.negativeReadsFilter)+', '+ \
            'primerBuffer = '+str(self.primerBuffer)+', '+ \
            'flankOut = '+str(self.flankOut)+' ,'+ \
            'stutterBuffer = '+str(self.stutterBuffer)+', '+ \
            'useCompress = '+str(self.useCompress)+', '+ \
            'withAlignment = '+str(self.withAlignment)+', '+ \
            'threshold = '+str(self.threshold)+', '+ \
            'clusterInfo = '+str(self.clusterInfo)+', '+ \
            'randomSubset = '+str(self.randomSubset)+', '+ \
            'creationTime = '+str(self.creationTime)+']'

from time import strftime as st    
class AnalysisResults(models.Model):
    """
    One-to one linked with analysis. Info for post-processing.
    """
    analysis = models.OneToOneField(Analysis)
    xmlFile = models.FileField(upload_to=lambda instance,filename: st('resultfiles/%Y/%m/%d/')+instance.analysis.dbname.fulldbname()+'.xml')
    figFile = models.ImageField(upload_to=lambda instance,filename: st('resultfiles/%Y/%m/%d/')+instance.analysis.dbname.fulldbname()+'.png')
